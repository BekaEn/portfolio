import React, { useState } from "react";
import mock01 from "../assets/images/mock01.png";
import mock02 from "../assets/images/mock02.png";
import mock03 from "../assets/images/mock03.png";
import mock04 from "../assets/images/mock04.png";
import mock05 from "../assets/images/mock05.png";
import mock06 from "../assets/images/mock06.png";
import mock07 from "../assets/images/mock07.png";
import mock08 from "../assets/images/mock08.png";
import mock09 from "../assets/images/mock09.png";
import mock10 from "../assets/images/mock10.png";
import mock11 from "../assets/images/mock11.png";
import "../assets/styles/Project.scss";

type Project = {
  id: number;
  title: string;
  description: string;
  backText: string;
  image: string;
  tags: string[];
};

const projects: Project[] = [
  {
    id: 1,
    title: "League of Legends Betting Discord Bot",
    description:
      "Discord Bot that reports live League of Legends match data and allows users to bet on outcomes using virtual currency.",
    backText: "Discord Bot that reports live League of Legends match data and allows users to bet on outcomes using virtual currency.\n\nHIGHLIGHTS:\n•  Integrated with Riot Games API for live match updates\n•  Implemented virtual betting system with user leaderboards\n•  Calculates individual player win rates and displays recent match history",
    image: mock01,
    tags: ["Python", "Discord Bot", "Data"],
  },
  {
    id: 2,
    title: "Flight Data Analysis Tool",
    description:
      "Python application leveraging MySQL, Pandas, and Scikit-learn to extract performance insights and predict delays.",
    backText: "Python application leveraging MySQL, Pandas, and Scikit-learn to extract performance insights and predict delays.\n\nHIGHLIGHTS:\n•  Processed large-scale flight datasets using Pandas for trend analysis\n•  Built a predictive model for flight delays using Scikit-learn\n•  Queried database dynamically based on user selections to generate predictive insights",
    image: mock02,
    tags: ["Python", "Data", "Machine Learning"],
  },
  {
    id: 3,
    title: "Decision Tree for Predicting Diabetes",
    description:
      "Trained and optimized a decision tree model to predict diabetes based on health indicators.",
    backText: "Trained and optimized a decision tree model to predict diabetes based on health indicators.\n\nHIGHLIGHTS:\n•  Used Scikit-learn to train decision tree classifier on medical dataset\n•  Tuned hyperparameters to maximize model accuracy\n•  Visualized decision tree structure with Graphviz and analyzed results using Matplotlib",
    image: mock03,
    tags: ["Python", "Data", "Machine Learning"],
  },
  {
    id: 4,
    title: "Training Linear and Logistic Regression Models",
    description:
      "Developed regression models using Python and Scikit-learn to analyze datasets.",
    backText: "Developed regression models using Python and Scikit-learn to analyze datasets.\n\nHIGHLIGHTS:\n•  Implemented both linear and logistic regression for classification and trend analysis\n•  Preprocessed and normalized datasets for accurate modeling\n•  Evaluated model performance using RMSE and classification accuracy",
    image: mock04,
    tags: ["Python", "Data", "Machine Learning"],
  },
  {
    id: 5,
    title: "Building Management System",
    description:
      "Raspberry Pi-based system to replicate fire-alarm, lighting, HVAC, and security controls using Python.",
    backText: "Raspberry Pi-based system to replicate fire-alarm, lighting, HVAC, and security controls using Python.\n\nHIGHLIGHTS:\n•  Integrated temperature and air quality sensors for environmental monitoring\n•  Used API to fetch local temperature data for dynamic HVAC control\n•  Implemented physical buttons for manual temperature adjustments\n•  Displayed real-time sensor readings and system status on an LED board",
    image: mock05,
    tags: ["Python", "Hands-on", "Circuit Design"],
  },
  {
    id: 6,
    title: "Character LLM Discord Bot",
    description:
      "Discord Bot powered by a character-based large language model for role-playing interactions.",
    backText: "Discord Bot powered by a character-based large language model for role-playing interactions.\n\nHIGHLIGHTS:\n•  Developed several AI bots, each with unique personalities and response styles\n•  Integrated with GetStream for LLM-based text generation\n•  Interactions via Discord commands trigger specific bot responses",
    image: mock06,
    tags: ["Python", "Discord Bot", "Data"],
  },
  {
    id: 7,
    title: "Market Data Discord Bot",
    description:
      "Discord bot to fetch, analyze, and export stock market data using APIs and Python.",
    backText: "Discord bot to fetch, analyze, and export stock market data using APIs and Python.\n\nHIGHLIGHTS:\n•  Integrated with financial APIs to retrieve real-time market data\n•  Implemented a notification system to alert users when a stock reaches a specified price\n•  Allows users to export stock data to CSV for further analysis",
    image: mock07,
    tags: ["Python", "Discord Bot", "Data"],
  },
  {
    id: 8,
    title: "Smart Mirror",
    description:
      "Smart Mirror device built with Raspberry Pi and OpenCV to detect facial features and overlay augmented reality elements.",
    backText: "Smart Mirror device using Raspberry Pi and OpenCV to detect facial features and overlay augmented reality elements.\n\nHIGHLIGHTS:\n•  Modified OpenCV model to track user's face and upper body\n•  Augmented reality mode places clothing PNGs on user image\n•  Functional UI with light mode/dark mode",
    image: mock08,
    tags: ["Python", "Hands-on"],
  },
  {
    id: 9,
    title: "Car Evaluation using kNN",
    description:
      "Implemented a K-Nearest Neighbors model to classify car evaluation data, optimizing hyperparameters for best accuracy.",
    backText: "Implemented a K-Nearest Neighbors model to classify car evaluation data, optimizing hyperparameters for best accuracy.\n\nHIGHLIGHTS:\n•  Trained kNN model on automotive evaluation dataset\n•  Tuned k-value to optimize classification performance\n•  Visualized classification boundaries using Matplotlib",
    image: mock09,
    tags: ["Python", "Data", "Machine Learning"],
  },
  {
    id: 10,
    title: "Pipelined MIPS Processor",
    description:
      "Designed and simulated a five-stage pipelined MIPS processor in Verilog.",
    backText: "Designed and simulated a five-stage pipelined MIPS processor in Verilog.\n\nHIGHLIGHTS:\n•  Implemented instruction fetch, decode, execute, memory, and writeback stages\n•  Optimized hazard detection and forwarding mechanisms\n•  Simulated and validated performance using testbench environments",
    image: mock10,
    tags: ["Circuit Design"],
  },
  {
    id: 11,
    title: "4-bit Adder/Subtractor",
    description:
      "Designed a 4-bit adder/subtractor in Cadence Virtuoso, building logic gates and entire component layouts from scratch.",
    backText: "Designed a 4-bit adder/subtractor in Cadence Virtuoso, building logic gates and entire component layouts from scratch.\n\nHIGHLIGHTS:\n•  Constructed full adder logic using fundamental CMOS gates\n•  Designed transistor-level schematics and layouts in Cadence Virtuoso\n•  Simulated circuit functionality and timing characteristics",
    image: mock11,
    tags: ["Circuit Design"],
  },
];

function ProjectCard() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const filteredProjects = projects.filter((project) => {
    const matchesSearch =
      project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTag = selectedTag
      ? project.tags.includes(selectedTag)
      : true;
    return matchesSearch && matchesTag;
  });

  const handleCardClick = (project: Project) => {
    setSelectedProject(project);
  };

  const closeModal = () => {
    setSelectedProject(null);
  };

  return (
    <div className="projects-container" id="projects">
      <div className="content-wrapper">
        <h1>Projects</h1>
        <div className="search-bar">
          <input
            type="text"
            placeholder="Search projects..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <div className="tags">
            {["Python", "Data", "Machine Learning", "Discord Bot", "Hands-on", "Circuit Design"].map(
              (tag) => (
                <button
                  key={tag}
                  className={`tag-button ${selectedTag === tag ? "active" : ""}`}
                  onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
                >
                  {tag}
                </button>
              )
            )}
          </div>
        </div>
        <div className="projects-grid">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="project-card"
              onClick={() => handleCardClick(project)}
            >
              <div className="project-inner">
                <img
                  src={project.image}
                  alt={project.title}
                  className="project-img"
                />
              </div>
              <h2>{project.title}</h2>
              <p>{project.description}</p>
            </div>
          ))}
        </div>
      </div>
      {selectedProject && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="close-btn" onClick={closeModal}>
              &times;
            </button>
            <h2>{selectedProject.title}</h2>
            <p className="modal-text">
              {selectedProject.backText.split("\n").map((line, index) => (
                <span key={index}>
                  {line.includes("HIGHLIGHTS:") ? (
                    <>
                      <strong>HIGHLIGHTS:</strong>
                      {line.replace("HIGHLIGHTS:", "")}
                    </>
                  ) : (
                    line
                  )}
                  <br />
                </span>
              ))}
            </p>
            <img src={selectedProject.image} alt={selectedProject.title} />
          </div>
        </div>
      )}
    </div>
  );
}

export default ProjectCard;
