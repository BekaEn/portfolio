import React from 'react';
import '../assets/styles/Qualifications.scss';
import SchoolIcon from '@mui/icons-material/School';
import WorkspacePremiumIcon from '@mui/icons-material/WorkspacePremium';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';

function Qualifications() {
  const qualifications = {
    education: [
      {
        title: "Bachelor of Science in Computer Engineering",
        institution: "University of California, Irvine",
        year: "2019 - 2024",
        description: "Major in Computer Engineering with focus on Machine Learning and Data Analysis"
      },
      {
        title: "High School Diploma",
        institution: "Westminster High School",
        year: "2015 - 2019",
        description: "Graduated with honors, completing AP coursework while in a STEM program focused on advanced mathematics and engineering topics"
      },
    ],
    certifications: [
      {
        title: "Learn Data Structures and Algorithms",
        institution: "Codecademy",
        year: "2023",
        description: "Proficiency in organizing and managing data using arrays, trees, graphs, and techniques such as sorting, searching, and dynamic programming",
        link: "https://www.codecademy.com/profiles/b.tb/certificates/7a1021b263de1990c643feb15d9f1f7a"
      },
      {
        title: "Learn Advanced Python",
        institution: "Codecademy",
        year: "2023",
        description: "Mastery of advanced Python concepts including object-oriented design, asynchronous programming, and memory optimization",
        link: "https://www.codecademy.com/profiles/b.tb/certificates/9360ffd5f85216dc4fbe5b19fe1db5e4"
      }
    ],
    achievements: [
      {
        title: "Eagle Scout Award",
        institution: "Boy Scouts of America",
        year: "2016",
        description: "Achieved Eagle Scout rank by completing 50+ merit badges and leading a community service project building a sustainable garden for a local middle school"
      },
      {
        title: "Top 25 Jhin Players",
        institution: "League of Legends NA",
        year: "2023",
        description: "Achieved a top ranking among millions of players, showcasing exceptional skill, strategic thinking, and consistent performance in competitive gameplay"
      }
    ]
  };

  return (
    <div id="qualifications" className="qualifications-section">
      <div className="qualifications-container">
        <h1>Qualifications</h1>
        
        <div className="qualifications-grid">
          {/* Education Section */}
          <div className="qualification-category">
            <div className="category-header">
              <SchoolIcon />
              <h2>Education</h2>
            </div>
            <div className="qualification-items">
              {qualifications.education.map((item, index) => (
                <div key={index} className="qualification-item">
                  <h3>{item.title}</h3>
                  <p className="institution">{item.institution}</p>
                  <p className="year">{item.year}</p>
                  <p className="description">{item.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Certifications Section */}
          <div className="qualification-category">
            <div className="category-header">
              <WorkspacePremiumIcon />
              <h2>Certifications</h2>
            </div>
            <div className="qualification-items">
              {qualifications.certifications.map((item, index) => (
                <div key={index} className="qualification-item">
                  <h3>
                    <a href={item.link} target="_blank" rel="noopener noreferrer">
                      {item.title}
                    </a>
                  </h3>
                  <p className="institution">{item.institution}</p>
                  <p className="year">{item.year}</p>
                  <p className="description">{item.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Achievements Section */}
          <div className="qualification-category">
            <div className="category-header">
              <EmojiEventsIcon />
              <h2>Achievements</h2>
            </div>
            <div className="qualification-items">
              {qualifications.achievements.map((item, index) => (
                <div key={index} className="qualification-item">
                  <h3>{item.title}</h3>
                  <p className="institution">{item.institution}</p>
                  <p className="year">{item.year}</p>
                  <p className="description">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Qualifications;
