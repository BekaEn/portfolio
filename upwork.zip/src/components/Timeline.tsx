import React, { useState, useEffect } from "react";
import "@fortawesome/free-regular-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBriefcase, faCaretDown, faCaretUp, faTrophy } from "@fortawesome/free-solid-svg-icons";
import {
  VerticalTimeline,
  VerticalTimelineElement,
} from "react-vertical-timeline-component";
import "react-vertical-timeline-component/style.min.css";
import "../assets/styles/Timeline.scss";

type Career = {
  id: number;
  title: string;
  subtitle: string;
  company: string;
  location: string;
  description: string;
  achievements: string[];
};

const careers: Career[] = [
  {
    id: 1,
    title: "Freelance Developer",
    company: "Self-Employed",
    location: "Remote",
    subtitle: "May 2024 — Present",
    description: "API Integration, GenAI/LLM, Project Management, Custom Discord Bots",
    achievements: [
      "Delivered 5 fully-functional Discord bots with advanced LLM features",
      "Integrated APIs such as OpenAI and Getstream to enhance bot capabilities",
      "Designed scalable bot architectures to support dynamic user interactions"
    ],
  },
  {
    id: 2,
    title: "Data Annotator / AI Trainer",
    company: "Data Annotation Tech",
    location: "Remote",
    subtitle: "May 2024 — Present",
    description: "AI Model Training, Code Quality Assurance, Algorithm Evaluation",
    achievements: [
      "Reviewed 40+ AI-generated coding responses weekly in various programming languages",
      "Evaluated 2-3 peer responses daily, providing feedback to improve annotation consistency",
      "Tested and debugged 160+ AI-generated scripts over 6 months"
    ],
  },
  {
    id: 3,
    title: "Store Associate & Technician",
    company: "The UPS Store",
    location: "Garden Grove, California, US",
    subtitle: "Oct 2023 — May 2024",
    description: "Customer Service, Shipping Operations, Process Optimization",
    achievements: [
      "Assisted 200+ customers daily with shipping, returns, and other services",
      "Shipped 5+ packages and processed dozens of returns daily, ensuring accuracy in data entry",
      "Streamlined systems and procedures to improve operational efficiency"
    ],
  },
  {
    id: 4,
    title: "Team Member",
    company: "HiroNori Craft Ramen",
    location: "Irvine, California, US",
    subtitle: "Apr 2022 — Jun 2022",
    description: "Food Preparation, Customer Service, Team Collaboration",
    achievements: [
      "Handled 50+ orders per hour, ensuring excellent service",
      "Maintained a clean workspace, boosting kitchen productivity",
      "Implemented feedback-driven service improvements"
    ],
  },
  {
    id: 5,
    title: "Project Management & Operations Intern",
    company: "Doe Lashes",
    location: "Remote",
    subtitle: "Oct 2020 — Jun 2021 ",
    description: "SMS Marketing Optimization, Inventory Management, Performance Analysis",
    achievements: [
      "Analyzed metrics to boost customer conversion by 15% in 6 months",
      "Optimized SMS campaigns to increase revenue by 20% in 3 months",
      "Streamlined inventory processes to cut order times by 25%"
    ],
  },
  {
    id: 6,
    title: "Team Member",
    company: "Marugame Udon",
    location: "Costa Mesa, California, US",
    subtitle: "Sep 2019 — Aug 2020",
    description: "Food Preparation, Customer Service, Team Collaboration",
    achievements: [
      "Handled 100+ orders per hour, ensuring fast and quality service",
      "Organized workspace to reduce prep time by 30 minutes daily",
      "Implemented feedback-driven service improvements"
    ],
  },
];

function Timeline() {
  const [expanded, setExpanded] = useState<{ [key: number]: boolean }>(() => {
    const initialState: { [key: number]: boolean } = {};
    careers.forEach(career => {
      initialState[career.id] = true;
    });
    return initialState;
  });

  const [isDarkMode, setIsDarkMode] = useState(true);

  useEffect(() => {
    const isLightMode = document.documentElement.classList.contains('light-mode');
    setIsDarkMode(!isLightMode);

    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.attributeName === 'class') {
          setIsDarkMode(!document.documentElement.classList.contains('light-mode'));
        }
      });
    });

    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class'],
    });

    return () => observer.disconnect();
  }, []);

  const toggleDetails = (id: number) => {
    setExpanded((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  return (
    <section className="timeline-section" id="career">
      <div className="timeline-container">
        <div className="section-header">
          <h1>Career History</h1>
          <p className="section-subtitle">My professional journey and experience</p>
        </div>

        <VerticalTimeline animate={true} lineColor={"#2b98c2"}>
          {careers.map((career) => (
            <VerticalTimelineElement
              key={career.id}
              className={`vertical-timeline-element--work ${!isDarkMode ? 'light-mode-element' : ''}`}
              contentArrowStyle={{ 
                borderRight: isDarkMode
                  ? "7px solid rgba(10, 25, 47, 0.7)"
                  : "7px solid rgba(255, 255, 255, 0.95)"
              }}
              date={career.subtitle}
              iconStyle={{ 
                background: "rgb(43, 152, 194)", 
                color: "#fff", 
                boxShadow: "0 0 0 4px rgba(255, 255, 255, 0.2)"
              }}
              icon={<FontAwesomeIcon icon={faBriefcase} />}
            >
              <div className="timeline-header">
                <h3 className="timeline-title">{career.title}</h3>
                <div className="company-info">
                  <h4 className="company-name">{career.company}</h4>
                  <span className="location">{career.location}</span>
                </div>
              </div>

              <p className="timeline-description">{career.description}</p>

              <div
                className={`timeline-details ${expanded[career.id] ? 'expanded' : ''}`}
                onClick={() => toggleDetails(career.id)}
              >
                <div className="toggle-button">
                  <span>{expanded[career.id] ? 'Show Less' : 'Show More'}</span>
                  <FontAwesomeIcon
                    icon={expanded[career.id] ? faCaretUp : faCaretDown}
                    className="toggle-icon"
                  />
                </div>
              </div>

              {expanded[career.id] && (
                <div className="expanded-content">
                  <div className="achievements">
                    <h5>
                      <FontAwesomeIcon icon={faTrophy} className="section-icon" />
                      Key Achievements
                    </h5>
                    <ul>
                      {career.achievements.map((achievement, index) => (
                        <li key={index}>{achievement}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </VerticalTimelineElement>
          ))}
        </VerticalTimeline>
      </div>
    </section>
  );
}

export default Timeline;