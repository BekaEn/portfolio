import React from 'react';
import '../assets/styles/About.scss';

function About() {
  return (
    <div id="about" className="about-section2">
      <div className="about-container">
        <h1>About Me</h1>
        
        <div className="about-content">
          <div className="about-text">
            <p className="intro">
              I'm Brian, a passionate data engineer based in California 
              with 5+ years of coding experience and an eagerness for creating 
              robust and scalable data solutions.
            </p>
            <p className="intro">
            I specialize in building data-driven systems, AI-powered automation tools,
            and workflows for both structured and unstructured data.
            </p>
            <p className="intro">
            I enjoy taking on intricate technical challenges and pushing the boundaries
            of innovation.
            </p>

            <div className="personal-info">
              <div className="info-item">
                <span className="label">Location:</span>
                <span className="value">New York, United States</span>
              </div>
              <div className="info-item">
                <span className="label">Email:</span>
                <span className="value">brian@btb.gg</span>
              </div>
              <div className="info-item">
                <span className="label">Availability:</span>
                <span className="value">Open to opportunities</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default About;
