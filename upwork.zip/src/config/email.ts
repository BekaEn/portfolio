export const emailConfig = {
  serviceId: "service_9gr6awh", // Replace with your EmailJS service ID
  templateId: "template_0km43js", // Replace with your EmailJS template ID
  publicKey: "qytDUh6NYFl8eRQ53ml03", // Replace with your EmailJS public key
} as const;
